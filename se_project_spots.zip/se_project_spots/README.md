# se_project_spots

A image sharing site.

## Describe

In this project I used html and the BEM method to build a page with images, texts, as well for buttons. For a better expierence, media queries are used order to adjust the elements depending on the size of the screen varing what sort of device a viewer is using. Other details used are importing fonts from different platforms.

## Tech Stack

- HTML
- CSS
- Responsive Design
- Media Queries

## Deployment

This webpage is deploy to Github Pages

[-Deployment Link: ](https://kevin-pickles.github.io/se_project_spots/)

[Watch the conclusion video](https://drive.google.com/file/d/1ZI9yPgkMOG5w79cwdFL9zzRezBHqXmka/view?usp=sharing)
